package com.DAO;

import java.sql.Connection;
/**
 * @Irene
 * Clase con los distintos métodos para ejecutar los comandos SQL de nuestra base de datos (CRUD + Contador de registros)
 */
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class BaseDatosPreparedStatement {
	private Connection conexion = null;

	private PreparedStatement preparedStatement = null;

	public BaseDatosPreparedStatement() {
	}

	public void insertPreparedStatement(String nombre, String apellidos, String dni, String especialista,
			String telefono) throws ClassNotFoundException {

		/**
		 * Metodo para insercion de nuevos registros en la BBDD
		 * 
		 * @param nombre, apellidos, dni, especialista (campos de la tabla "pacientes"
		 *                en la BBDD. No hay PK y pueden ser null
		 **/

		try {
			Class.forName("org.sqlite.JDBC");
			conexion = DriverManager.getConnection("jdbc:sqlite:clinica.sqlite");
			preparedStatement = conexion.prepareStatement

			("INSERT INTO pacientes(nombre, apellidos, dni, especialista, telefono) VALUES (?,?,?,?,?)");

			preparedStatement.setString(1, nombre);
			preparedStatement.setString(2, apellidos);
			preparedStatement.setString(3, dni);
			preparedStatement.setString(4, especialista);
			preparedStatement.setString(5, telefono);
			preparedStatement.executeUpdate();
			System.out.println("paciente registrado correctamente");
		} catch (SQLException ex) {
			System.out.println("No se ha podido registrar el paciente");
		}
	}

	public void selectPreparedStatement(String nombre) throws ClassNotFoundException {
		try {

			/**
			 * Metodo para seleccion de registros por nombre
			 * 
			 * @param nombre (nombre del paciente sin apellidos
			 **/
			Class.forName("org.sqlite.JDBC");
			conexion = DriverManager.getConnection("jdbc:sqlite:clinica.sqlite");
			preparedStatement = conexion.prepareStatement

			("SELECT * FROM pacientes WHERE nombre=?");

			preparedStatement.setString(1, nombre);
			try (ResultSet rs = preparedStatement.executeQuery()) {
				while (rs.next()) {
					System.out.println("Nombre: " + rs.getString(1) + " Apellidos: " + rs.getString(2) + " dni: "
							+ rs.getString(3) + " Especialista: " + rs.getString(4) + " Telefono: " + rs.getString(5));
				}
			}
			preparedStatement.close();
		} catch (SQLException ex) {
			System.out.println("No se ha podido encontrar el paciente" + ex);
		}

	}

	public void selectPreparedStatementTodo() throws ClassNotFoundException {
		try {

			/** Metodo para la visualizacion de todos los registros en la bbdd **/
			Class.forName("org.sqlite.JDBC");
			conexion = DriverManager.getConnection("jdbc:sqlite:clinica.sqlite");
			preparedStatement = conexion.prepareStatement("SELECT * FROM pacientes");
			try (ResultSet rs = preparedStatement.executeQuery()) {
				while (rs.next()) {
					System.out.println("Nombre: " + rs.getString(1) + " Apellidos: " + rs.getString(2) + " DNI: "
							+ rs.getString(3) + " Especialista: " + rs.getString(4) + " Telefono: " + rs.getString(5));
				}
			}
			preparedStatement.close();
		} catch (SQLException ex) {
			System.out.println("No se han podido recuperar los pacientes del registro" + ex);
		}

	}

	public void updatePreparedStatement(String dni, String especialista) throws ClassNotFoundException {
		/**
		 * Metodo para la actualizacion del especialista, seleccionando el dni para la
		 * extraccion de registro
		 * 
		 * @param dni
		 * @param especialista
		 **/
		try {
			Class.forName("org.sqlite.JDBC");
			conexion = DriverManager.getConnection("jdbc:sqlite:clinica.sqlite");
			preparedStatement = conexion.prepareStatement("UPDATE pacientes SET especialista=? WHERE dni=?");
			preparedStatement.setString(1, especialista);
			preparedStatement.setString(2, dni);
			preparedStatement.executeUpdate();
			System.out.println("Registro modificado");

		} catch (SQLException ex) {
			JOptionPane.showMessageDialog(null, "Error al modificar el registro");
		}
	}

	public void deletePreparedStatement(String dni) throws ClassNotFoundException {
		/**
		 * Metodo para el borrado de registros en la bbdd
		 * 
		 * @param dni
		 **/
		try {
			Class.forName("org.sqlite.JDBC");
			conexion = DriverManager.getConnection("jdbc:sqlite:clinica.sqlite");
			preparedStatement = conexion.prepareStatement("DELETE FROM pacientes WHERE dni=?");
			preparedStatement.setString(1, dni);
			preparedStatement.executeUpdate();
			System.out.println("Se ha eliminado del registro");

		} catch (SQLException ex) {
			System.out.println("No se pudo realizar la eliminacion");
		}
	}

	public void selectPreparedStatementApellidos(String apellidos) throws ClassNotFoundException {
		/**
		 * Metodo para la seleccion de pacientes por apellidos
		 * 
		 * @param apellidos
		 **/
		try {
			Class.forName("org.sqlite.JDBC");
			conexion = DriverManager.getConnection("jdbc:sqlite:clinica.sqlite");
			preparedStatement = conexion.prepareStatement

			("SELECT  FROM pacientes WHERE apellidos=?");

			preparedStatement.setString(2, apellidos);
			try (ResultSet rs = preparedStatement.executeQuery()) {
				while (rs.next()) {
					System.out.println("Nombre: " + rs.getString(1) + " DNI: " + rs.getString(3) + " Especialista: "
							+ rs.getString(4) + " Telefono: " + rs.getString(5));
				}
			}
			preparedStatement.close();
		} catch (SQLException ex) {
			System.out.println("No se ha podido encontrar el paciente  . Error." + ex);
		}
	}

	public int selectPreparedStatementCount2() throws ClassNotFoundException {
		/** Metodo para contabilizar registros en la tabla **/
		int count = 0;
		try {
			Class.forName("org.sqlite.JDBC");
			conexion = DriverManager.getConnection("jdbc:sqlite:clinica.sqlite");

			preparedStatement = conexion.prepareStatement("SELECT * FROM pacientes");

			try (ResultSet rs = preparedStatement.executeQuery()) {
				while (rs.next()) {

					count++;
				}
			}
			preparedStatement.close();
		} catch (SQLException ex) {
			System.out.println("No se han podido recuperar los pacientes del registro" + ex);
		}
		return count;
	}

}
