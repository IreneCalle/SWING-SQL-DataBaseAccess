package com.DAO;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

import javax.swing.JOptionPane;

import com.gestionLogs.LogsFicheros;

/**
 * @author Irene Esta clase permite el acceso a los datos en caso de caida de la
 *         app grafica (acceso por consola) a través de un menú switch con las
 *         distintas opciones CRUD para la gestión de nuestra BBDD
 * 
 * @see BaseDatosPreparedStatement
 **/

public class TestClinica {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		Scanner sc = new Scanner(System.in);
		int opcion = 0;
		String nombre, apellidos, dni, especialista, telefono;
		BaseDatosPreparedStatement statement;

		do {
			System.out.println(
					"Bienvenido al registro de la clínica. Por favor, pulsa la tecla correspondiente para seleccionar una opcion");
			System.out.println("1. Insertar paciente");
			System.out.println("2. Visualizar por nombre");
			System.out.println("3. Visualizar todos");
			System.out.println("4. Actualizar por telefono");
			System.out.println("5. Eliminar registro");
			System.out.println("6. Salir");

			opcion = sc.nextInt();

			switch (opcion) {
			case 1:
				System.out.println("Introduce el nombre del paciente");
				nombre = sc.next(); // Datos.getNombre
				System.out.println("Introduce los apellidos");
				apellidos = sc.next();
				System.out.println("Introduce el dni");
				dni = sc.next();
				System.out.println("Introduce el numero de especialista");
				especialista = sc.next();
				System.out.println("Introduce el telefono");
				telefono = sc.next();
				statement = new BaseDatosPreparedStatement();

				try {
					statement.insertPreparedStatement(nombre, apellidos, dni, especialista, telefono);

					/** llamamos al metodo que registra los aciertos en el documento de aciertos **/
					LogsFicheros.escribeAcierto();

				} catch (ClassNotFoundException ex) {
					System.err.println("Error al insertar el paciente en la base de datos" + ex);
					/** llamamos al metodo que registra los fallos en el documento de fallos **/
					LogsFicheros.escribeFallo();
				}
				break;
			case 2: {
				System.out.println("Introduce el nombre del paciente con la primera letra en mayuscula");
				nombre = sc.next();
				statement = new BaseDatosPreparedStatement();

				try {
					statement.selectPreparedStatement(nombre);
				} catch (ClassNotFoundException ex) {
					System.err.println("Error al realizar la seleccion");
					LogsFicheros.escribeFallo();

				}
				break;
			}

			case 3:
				statement = new BaseDatosPreparedStatement();

				try {
					statement.selectPreparedStatementTodo();
				} catch (ClassNotFoundException ex) {
					System.err.println("Error al realizar la seleccion de todos los pacientes");
					System.err.println(ex);
				}
				break;

			case 4:
				System.out.println("Introduce el DNI");
				dni = sc.next();
				System.out.println("Introduce el especialista");
				especialista = sc.next();
				statement = new BaseDatosPreparedStatement();

				try {
					statement.updatePreparedStatement(dni, especialista);
					JOptionPane.showInputDialog(null, "Registro actualizado con éxito");
				} catch (ClassNotFoundException ex) {
					JOptionPane.showInputDialog(null, "Error al actualizar");

				}
				break;
			case 5:
				statement = new BaseDatosPreparedStatement();
				System.out.println("Introduce el telefono");
				especialista = sc.next();
				try {
					statement.deletePreparedStatement(especialista);
				} catch (ClassNotFoundException ex) {
					System.err.println("Error al eliminar");
				}
				break;
			case 6:
				System.exit(0);
				break;
			}

		} while (opcion != 6);
	}

}
