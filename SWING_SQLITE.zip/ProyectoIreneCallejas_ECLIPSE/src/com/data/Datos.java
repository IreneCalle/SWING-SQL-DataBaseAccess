package com.data;

/**
 * @author Irene Clase creada para poder trabajan con registros a través de
 *         beans que describan los distintos campos de la tabla en sus variables
 * 
 * 
 **/

public class Datos {

	private String nombre;
	private String apellidos;
	private String dni;
	private String especialista;
	private String telefono;

	public Datos() {
		super();
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public String getEspecialista() {
		return especialista;
	}

	public void setEspecialista(String especialista) {
		this.especialista = especialista;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

}
