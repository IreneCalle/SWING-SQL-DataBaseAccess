package com.gestionLogs;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

/**
 * @author Irene
 * 
 *         Esta clase escribe fallos y aciertos de los registros de INSERCION en
 *         la BBDD y les añade la hora y fecha de la ejecución
 */
public class LogsFicheros {
	public static void escribeAcierto() {
		try (BufferedWriter ficheroDos = new BufferedWriter(new FileWriter("logsOK.TXT", true))) {
			try {
				LocalDateTime now = LocalDateTime.now();

				ficheroDos.write("Registro insertado correctamente a las" + java.time.LocalDateTime.now());
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try {
				ficheroDos.newLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

	}

	public static void escribeFallo() {
		try (BufferedWriter ficheroTres = new BufferedWriter(new FileWriter("logsFAIL.TXT", true))) {
			try {
				ficheroTres.write("Registro fallido a las " + java.time.LocalDateTime.now());
			} catch (IOException e1) {

				e1.printStackTrace();
			}
			try {
				ficheroTres.newLine();
			} catch (IOException e) {

				e.printStackTrace();
			}
		} catch (IOException e2) {

			e2.printStackTrace();
		}

	}

}
