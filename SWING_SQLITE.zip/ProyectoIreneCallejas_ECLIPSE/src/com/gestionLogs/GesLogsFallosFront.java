package com.gestionLogs;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 * @author Irene
 * 
 *         Esta clase contiene un metodo que lee los registros fallidos del
 *         fichero logsFail y los asigna al return de su metodo mostrarLogs
 */

public class GesLogsFallosFront {

	public String areaTexto = "";

	public GesLogsFallosFront() {
	};

	public String mostrarLogs(String areaTexto) {
		/**
		 * @param areaTexto es simplemente la variable donde guardamos el texto leido
		 * @return lee las lineas con un contador concatenado al contenido de la linea y
		 *         un salto de linea
		 * 
		 */
		this.areaTexto = areaTexto;
		FileReader entrada = null;
		try {
			entrada = new FileReader("logsFAIL.txt");
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		BufferedReader mibuffer = new BufferedReader(entrada);
		String linea = "";
		int i = -1;
		while (linea != null) {
			try {
				linea = mibuffer.readLine();
				i++;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			if (linea != null)
				areaTexto = areaTexto + (i + " " + linea + "\n");

		}

		System.out.println("-------------");
		System.out.println(areaTexto);
		return areaTexto;
	}
}
