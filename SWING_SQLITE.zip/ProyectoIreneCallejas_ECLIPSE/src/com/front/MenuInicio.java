package com.front;

/**
 *
 * @author Irene Esta clase abra nuestro menu de inicio, en el que seleccionamos
 *         una de las opciones del combobox comboOpciones para navegar por
 *         nuestro programa que nos permitirá realizar CRUDs de la BBDD.
 */
public class MenuInicio extends javax.swing.JFrame {

	/**
	 * Crea un nuevoMenuInicio
	 */
	public MenuInicio() {
		initComponents();
		this.setTitle("Clinica Aepi. Menu inicio");
	}

	/**
	 * Inicializador de nuestra form
	 */
	@SuppressWarnings("unchecked")
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		OpcionVisualizar = new javax.swing.JComboBox<>();
		ComboOpciones = new javax.swing.JComboBox<>();
		jScrollPane1 = new javax.swing.JScrollPane();
		jList1 = new javax.swing.JList<>();
		jLabel6 = new javax.swing.JLabel();
		jScrollPane2 = new javax.swing.JScrollPane();
		jTextPane1 = new javax.swing.JTextPane();
		jComboOpciones = new javax.swing.JComboBox<>();
		jLabel1 = new javax.swing.JLabel();
		jLabel2 = new javax.swing.JLabel();
		btnAceptar = new javax.swing.JButton();

		OpcionVisualizar.setModel(
				new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

		ComboOpciones.setModel(
				new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
		ComboOpciones.addComponentListener(new java.awt.event.ComponentAdapter() {
			public void componentShown(java.awt.event.ComponentEvent evt) {
				ComboOpcionesComponentShown(evt);
			}
		});
		ComboOpciones.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				ComboOpcionesActionPerformed(evt);
			}
		});

		jList1.setModel(new javax.swing.AbstractListModel<String>() {
			String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };

			public int getSize() {
				return strings.length;
			}

			public String getElementAt(int i) {
				return strings[i];
			}
		});
		jScrollPane1.setViewportView(jList1);

		jLabel6.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
		jLabel6.setText("Datos para nuevo registro");

		jScrollPane2.setViewportView(jTextPane1);

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setBackground(new java.awt.Color(204, 255, 204));
		setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
		setType(java.awt.Window.Type.POPUP);

		jComboOpciones.setBackground(new java.awt.Color(51, 204, 255));
		jComboOpciones.setModel(new javax.swing.DefaultComboBoxModel<>(
				new String[] { "INSERTAR", "VISUALIZAR", "BORRAR", "ACTUALIZAR", "LOGS" }));
		jComboOpciones.addComponentListener(new java.awt.event.ComponentAdapter() {
			public void componentShown(java.awt.event.ComponentEvent evt) {
				jComboOpcionesComponentShown(evt);
				Registros(evt);
				Errores(evt);
			}
		});
		jComboOpciones.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jComboOpcionesActionPerformed(evt);
			}
		});

		jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
		jLabel1.setForeground(new java.awt.Color(51, 51, 51));
		jLabel1.setText("Por favor, selecciona una opcion");

		jLabel2.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
		jLabel2.setText("Menu de inicio");

		btnAceptar.setText("Aceptar");
		btnAceptar.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btnAceptarActionPerformed(evt);
			}
		});

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(layout.createSequentialGroup().addGap(22, 22, 22)
						.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
								.addComponent(btnAceptar)
								.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 244,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addComponent(jLabel1).addComponent(jComboOpciones,
												javax.swing.GroupLayout.PREFERRED_SIZE, 276,
												javax.swing.GroupLayout.PREFERRED_SIZE)))
						.addContainerGap(102, Short.MAX_VALUE)));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(layout.createSequentialGroup().addGap(21, 21, 21)
						.addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 25,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGap(48, 48, 48).addComponent(jLabel1)
						.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addComponent(jComboOpciones, javax.swing.GroupLayout.PREFERRED_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGap(69, 69, 69).addComponent(btnAceptar).addContainerGap(70, Short.MAX_VALUE)));

		pack();
	}// </editor-fold>

	private void ComboOpcionesActionPerformed(java.awt.event.ActionEvent evt) {
		// TODO add your handling code here:
	}

	private void ComboOpcionesComponentShown(java.awt.event.ComponentEvent evt) {
		// TODO add your handling code here:
	}

	private void btnAceptarActionPerformed(java.awt.event.ActionEvent evt) {
		/**
		 * Con este condicional gestionamos la navegacion entre las distinas ventanas
		 * obteniendo el indice de cada una de las opciones
		 */

		int opcion = jComboOpciones.getSelectedIndex();
		if (opcion == 0) {
			CuadroInsertar insertar = new CuadroInsertar();
			insertar.setVisible(true);
			this.setVisible(false);
		}
		if (opcion == 1) {
			CuadroVisualizar visualizar = new CuadroVisualizar();
			visualizar.setVisible(true);
			this.setVisible(false);
		}
		if (opcion == 2) {
			CuadroBorrar borrar = new CuadroBorrar();
			borrar.setVisible(true);
			this.setVisible(false);
		}

		if (opcion == 3) {
			CuadroActualizar actualizar = new CuadroActualizar();
			actualizar.setVisible(true);
			this.setVisible(false);
		}

		if (opcion == 4) {
			CuadroLogs logs = new CuadroLogs();
			logs.setVisible(true);
			this.setVisible(false);
		}

	}

	private void jComboOpcionesActionPerformed(java.awt.event.ActionEvent evt) {

	}

	private void jComboOpcionesComponentShown(java.awt.event.ComponentEvent evt) {

	}

	private void Registros(java.awt.event.ComponentEvent evt) {

	}

	private void Errores(java.awt.event.ComponentEvent evt) {

	}

	/**
	 * @param argumentos de comando de linea
	 */
	public static void main(String args[]) {
		/* Set the Nimbus look and feel */
		// <editor-fold defaultstate="collapsed" desc=" Look and feel setting code
		// (optional) ">
		/*
		 * If Nimbus (introduced in Java SE 6) is not available, stay with the default
		 * look and feel. For details see
		 * http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
		 */
		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(MenuInicio.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(MenuInicio.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(MenuInicio.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(MenuInicio.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		}
		// </editor-fold>

		/* Create and display the form */
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new MenuInicio().setVisible(true);
			}
		});
	}

	// Declaracion de variables, no modificar
	private javax.swing.JComboBox<String> ComboOpciones;
	private javax.swing.JComboBox<String> OpcionVisualizar;
	private javax.swing.JButton btnAceptar;
	private javax.swing.JComboBox<String> jComboOpciones;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JList<String> jList1;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JScrollPane jScrollPane2;
	private javax.swing.JTextPane jTextPane1;
	// Fin de declararion de variables
}
