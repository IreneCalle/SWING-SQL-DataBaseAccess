package com.front;

import com.gestionLogs.GesLogsFallosFront;
import com.gestionLogs.GesLogsFront;

/**
 * @author Irene Clase que contiene los registros completados con éxito y
 *         fallidos y da la opcion al usuario de visualizar cada uno de ellos
 */

public class CuadroLogs extends javax.swing.JFrame {

	/**
	 * Crea un nuevo cuadro
	 */
	public CuadroLogs() {
		this.setSize(950, 800);
		this.setTitle("Registros realizados en el sistema");

		initComponents();
	}

	/**
	 * Inicializador de la ventana
	 */
	@SuppressWarnings("unchecked")
	// <editor-fold defaultstate="collapsed" desc="Generated Code">
	private void initComponents() {

		jOptionPane1 = new javax.swing.JOptionPane();
		jFrame1 = new javax.swing.JFrame();
		jFrame2 = new javax.swing.JFrame();
		jScrollPane1 = new javax.swing.JScrollPane();
		jTable1 = new javax.swing.JTable();
		jPopupMenu1 = new javax.swing.JPopupMenu();
		btnMostrarLogs = new javax.swing.JToggleButton();
		jLabel6 = new javax.swing.JLabel();
		jLabel1 = new javax.swing.JLabel();
		btnVolver = new javax.swing.JButton();
		jLabel2 = new javax.swing.JLabel();
		btnMostrarLogsFallos = new javax.swing.JToggleButton();
		jScrollPane3 = new javax.swing.JScrollPane();
		areaTextoFallos = new javax.swing.JTextArea();
		jScrollPane4 = new javax.swing.JScrollPane();
		areaTextoLogs = new javax.swing.JTextArea();
		areaTextoLogs.setEditable(false);
		areaTextoFallos.setEditable(false);

		javax.swing.GroupLayout jFrame1Layout = new javax.swing.GroupLayout(jFrame1.getContentPane());
		jFrame1.getContentPane().setLayout(jFrame1Layout);
		jFrame1Layout.setHorizontalGroup(jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGap(0, 400, Short.MAX_VALUE));
		jFrame1Layout.setVerticalGroup(jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGap(0, 300, Short.MAX_VALUE));

		javax.swing.GroupLayout jFrame2Layout = new javax.swing.GroupLayout(jFrame2.getContentPane());
		jFrame2.getContentPane().setLayout(jFrame2Layout);
		jFrame2Layout.setHorizontalGroup(jFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGap(0, 400, Short.MAX_VALUE));
		jFrame2Layout.setVerticalGroup(jFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGap(0, 300, Short.MAX_VALUE));

		jTable1.setModel(
				new javax.swing.table.DefaultTableModel(
						new Object[][] { { null, null, null, null }, { null, null, null, null },
								{ null, null, null, null }, { null, null, null, null } },
						new String[] { "Title 1", "Title 2", "Title 3", "Title 4" }));
		jScrollPane1.setViewportView(jTable1);

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		btnMostrarLogs.setText("Mostrar");
		btnMostrarLogs.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btnMostrarLogsActionPerformed(evt);
			}
		});

		jLabel6.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
		jLabel6.setText("Visualizar el histórico de registros");

		jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
		jLabel1.setForeground(new java.awt.Color(102, 102, 102));
		jLabel1.setText("Histórico de los registros realizados con éxito");

		btnVolver.setText("Volver");
		btnVolver.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btnVolverActionPerformed(evt);
			}
		});

		jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
		jLabel2.setForeground(new java.awt.Color(102, 102, 102));
		jLabel2.setText("Histórico de los fallos de registro en el sistema");

		btnMostrarLogsFallos.setText("Mostrar");
		btnMostrarLogsFallos.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				btnMostrarLogsFallosActionPerformed(evt);
			}
		});

		areaTextoFallos.setColumns(20);
		areaTextoFallos.setRows(5);
		jScrollPane3.setViewportView(areaTextoFallos);

		areaTextoLogs.setColumns(20);
		areaTextoLogs.setRows(5);
		jScrollPane4.setViewportView(areaTextoLogs);

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(layout
				.createSequentialGroup().addGap(18, 18, 18)
				.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 312,
								javax.swing.GroupLayout.PREFERRED_SIZE)
						.addGroup(layout.createSequentialGroup()
								.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
										.addGroup(layout.createSequentialGroup().addGap(7, 7, 7)
												.addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 269,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(btnMostrarLogs, javax.swing.GroupLayout.PREFERRED_SIZE,
														102, javax.swing.GroupLayout.PREFERRED_SIZE))
										.addComponent(jScrollPane4))
								.addGap(70, 70, 70)
								.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
										.addGroup(layout.createSequentialGroup()
												.addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 269,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
												.addComponent(btnMostrarLogsFallos,
														javax.swing.GroupLayout.PREFERRED_SIZE, 102,
														javax.swing.GroupLayout.PREFERRED_SIZE))
										.addComponent(jScrollPane3))))
				.addGap(39, 39, 39).addComponent(btnVolver).addGap(27, 27, 27)));
		layout.setVerticalGroup(
				layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						.addGroup(javax.swing.GroupLayout.Alignment.TRAILING,
								layout.createSequentialGroup().addGap(18, 18, 18).addComponent(jLabel6)
										.addGap(18, 18, 18)
										.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
												.addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 23,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addComponent(btnMostrarLogs)
												.addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 23,
														javax.swing.GroupLayout.PREFERRED_SIZE)
												.addComponent(btnMostrarLogsFallos))
										.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
												.addGroup(layout
														.createSequentialGroup()
														.addComponent(jScrollPane4,
																javax.swing.GroupLayout.DEFAULT_SIZE, 250,
																Short.MAX_VALUE)
														.addGap(20, 20, 20))
												.addGroup(layout.createSequentialGroup().addGroup(layout
														.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
														.addComponent(jScrollPane3,
																javax.swing.GroupLayout.Alignment.LEADING)
														.addGroup(layout.createSequentialGroup().addPreferredGap(
																javax.swing.LayoutStyle.ComponentPlacement.RELATED,
																javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
																.addComponent(btnVolver)))
														.addGap(23, 23, 23)))));

		pack();
	}// </editor-fold>

	private void btnMostrarLogsActionPerformed(java.awt.event.ActionEvent evt) {

		/**
		 * Instanciamos a la clase que se encarga de escribir linea por linea desde
		 * nuestro fichero de fallos con el metodo mostrarLogs y le asignamos su return
		 * (string) al área de texto "areaTextoLogs"
		 */
		areaTextoFallos.setText(" ");

		String t = "  ";
		areaTextoLogs.setText(t);

		GesLogsFront geslogs = new GesLogsFront();

		areaTextoLogs.setText(geslogs.mostrarLogs(geslogs.areaTexto));

	}

	private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {

		this.setVisible(false);

		MenuInicio i = new MenuInicio();
		i.setVisible(true);
	}

	private void btnMostrarLogsFallosActionPerformed(java.awt.event.ActionEvent evt) {
		/**
		 * Instanciamos a la clase que se encarga de escribir linea por linea desde
		 * nuestro fichero de fallos con el metodo mostrarLogs y le asignamos su return
		 * (string) al área de texto "areaTextoFallos"
		 */
		areaTextoLogs.setText(" ");

		areaTextoFallos.setText(" ");
		GesLogsFallosFront geslogs = new GesLogsFallosFront();
		areaTextoFallos.setText(geslogs.mostrarLogs(""));

	}

	/**
	 * @param argumentos de linea de comandos
	 */
	public static void main(String args[]) {
		/* Set the Nimbus look and feel */
		// <editor-fold defaultstate="collapsed" desc=" Look and feel setting code
		// (optional) ">
		/*
		 * If Nimbus (introduced in Java SE 6) is not available, stay with the default
		 * look and feel. For details see
		 * http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
		 */
		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(CuadroLogs.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(CuadroLogs.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(CuadroLogs.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(CuadroLogs.class.getName()).log(java.util.logging.Level.SEVERE, null,
					ex);
		}
		// </editor-fold>
		// </editor-fold>
		// </editor-fold>
		// </editor-fold>
		// </editor-fold>
		// </editor-fold>
		// </editor-fold>
		// </editor-fold>

		/* Create and display the form */
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new CuadroLogs().setVisible(true);
				new CuadroLogs().setSize(950, 700);

			}
		});
	}

	// Variables declaration - do not modify
	private javax.swing.JTextArea areaTextoFallos;
	private javax.swing.JTextArea areaTextoLogs;
	private javax.swing.JToggleButton btnMostrarLogs;
	private javax.swing.JToggleButton btnMostrarLogsFallos;
	private javax.swing.JButton btnVolver;
	private javax.swing.JFrame jFrame1;
	private javax.swing.JFrame jFrame2;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel6;
	private javax.swing.JOptionPane jOptionPane1;
	private javax.swing.JPopupMenu jPopupMenu1;
	private javax.swing.JScrollPane jScrollPane1;
	private javax.swing.JScrollPane jScrollPane3;
	private javax.swing.JScrollPane jScrollPane4;
	private javax.swing.JTable jTable1;
	// End of variables declaration
}
