package com.ejecucion;

import java.util.Timer;
import java.util.TimerTask;

import com.front.MenuInicio;
import com.front.TareaPopUp;

/**
 * @author Irene Esta clase inicia todo el programa, iniciando nuestra ventana
 *         de inicio y la tarea paralela que mostrará una ventana emergente con
 *         el número de registros en la BBDD en el momento.
 */

public class EjecucionPrograma {

	public static void main(String[] args) throws ClassNotFoundException {
		MenuInicio inicio = new MenuInicio();
		inicio.setVisible(true);

		Timer timer = new Timer();
		TareaPopUp tareaPopUp = new TareaPopUp();

		TimerTask task = new TimerTask() {

			@Override
			public void run() {
				try {

					/**
					 * abrimos a la tarea pop up que contabiliza a tiempo real los registros en bbdd
					 **/
					TareaPopUp tareaPopUp = new TareaPopUp();
					tareaPopUp.setVisible(true);
				} catch (Exception ex) {
					System.out.println(ex.getMessage());
				}
			}
		};

		/**
		 * Hemos alargado hasta 10000 ms la frecuencia de la ventana emergente para que
		 * no sea tan molesta la ventana emergente
		 **/
		timer.scheduleAtFixedRate(task, 3000, 10000);

	}

}
